export const DJANGO_API_URL = 'http://127.0.0.1:8000/api';

export function getApiUrl(path: string): string {
  let cleanPath = path.startsWith('/') ? path : `/${path}`;
  if (cleanPath.startsWith('/api')) {
    cleanPath = cleanPath.replace('/api', '');
  }
  return `${DJANGO_API_URL}${cleanPath}`;
}
